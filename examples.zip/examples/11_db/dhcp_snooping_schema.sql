create table dhcp (
    mac          text primary key,
    ip           text,
    vlan         text,
    interface    text
);
