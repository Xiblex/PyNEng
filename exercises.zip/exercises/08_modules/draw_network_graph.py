# -*- coding: utf-8 -*-
# Based on http://matthiaseisen.com/articles/graphviz/

import sys

try:
    import graphviz as gv
except ImportError:
    print "Module graphviz needs to be installed"
    print "pip install graphviz"
    sys.exit()


styles = {
    'graph': {
        'label': 'Network Map',
        'fontsize': '16',
        'fontcolor': 'white',
        'bgcolor': '#333333',
        'rankdir': 'BT',
    },
    'nodes': {
        'fontname': 'Helvetica',
        'shape': 'box',
        'fontcolor': 'white',
        'color': '#006699',
        'style': 'filled',
        'fillcolor': '#006699',
        'margin': '0.4',
    },
    'edges': {
        'style': 'dashed',
        'color': 'green',
        'arrowhead': 'open',
        'fontname': 'Courier',
        'fontsize': '14',
        'fontcolor': 'white',
    }
}

def apply_styles(graph, styles):
    graph.graph_attr.update(
        ('graph' in styles and styles['graph']) or {}
    )
    graph.node_attr.update(
        ('nodes' in styles and styles['nodes']) or {}
    )
    graph.edge_attr.update(
        ('edges' in styles and styles['edges']) or {}
    )
    return graph


def draw_topology(topology_dict):
    '''
    topology_dict - словарь с описанием топологии

    Этот словарь
        {('R4', 'Fa0/1'): ('R5', 'Fa0/1'),
         ('R4', 'Fa0/2'): ('R6', 'Fa0/0')}

    соответствует топологии:
    [ R5 ]-Fa0/1 --- Fa0/1-[ R4 ]-Fa0/2---Fa0/0-[ R6 ]

    Функция генерирует топологию, в формате svg.
    И записывает файл topology.svg в каталог img.
    '''
    nodes = set([key[0] for key in topology_dict.keys() + topology_dict.values()])

    g1 = gv.Graph(format='svg')

    for node in nodes:
        g1.node(node)

    for key, value in topology_dict.iteritems():
        head, t_label = key
        tail, h_label = value
        g1.edge(head, tail, headlabel=h_label, taillabel=t_label, label=" "*12)

    g1 = apply_styles(g1, styles)
    filename = g1.render(filename='img/topology')
    print "Graph saved in", filename

