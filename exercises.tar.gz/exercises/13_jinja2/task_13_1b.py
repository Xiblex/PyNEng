# -*- coding: utf-8 -*-

"""
Задание 13.1b

Дополнить функцию generate_cfg_from_template из задания 13.1 или 13.1a:
* добавить поддержку аргументов окружения (Environment)

Функция generate_cfg_from_template должна принимать любые аргументы,
которые принимает класс Environment и просто передавать их ему.

Проверить функциональность на аргументах:
* trim_blocks
* lstrip_blocks

"""

