# -*- coding: utf-8 -*-
'''
Задание 3.2

Преобразовать строку MAC с формата XXXX:XXXX:XXXX в XXXX.XXXX.XXXX
'''

MAC = "AAAA:BBBB:CCCC"
